$_L(["java.io.IOException"],"java.io.ObjectStreamException",null,function(){
c$=$_T(java.io,"ObjectStreamException",java.io.IOException);
});
