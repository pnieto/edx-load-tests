$_L(["java.lang.RuntimeException"],"java.lang.TypeNotPresentException",null,function(){
c$=$_C(function(){
this.$typeName=null;
$_Z(this,arguments);
},java.lang,"TypeNotPresentException",RuntimeException);
$_K(c$,
function(typeName,cause){
$_R(this,TypeNotPresentException,["Type "+typeName+" not present",cause]);
this.$typeName=typeName;
},"~S,Throwable");
$_M(c$,"typeName",
function(){
return this.$typeName;
});
});
