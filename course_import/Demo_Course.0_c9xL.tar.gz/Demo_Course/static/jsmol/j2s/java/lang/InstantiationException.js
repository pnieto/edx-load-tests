$_L(["java.lang.Exception"],"java.lang.InstantiationException",null,function(){
c$=$_T(java.lang,"InstantiationException",Exception);
});
